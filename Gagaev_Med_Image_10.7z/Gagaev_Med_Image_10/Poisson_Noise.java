import ij.IJ;
import ij.ImagePlus;
import ij.gui.GenericDialog;
import ij.plugin.filter.PlugInFilter;
import ij.process.*;
import java.util.Random;
import java.awt.Rectangle;

/**
 * This plugin adds Poisson distributed noise to each pixel of an image. This
 * plugin uses a simple way to generate random Poisson-distributed numbers.
 * Poisson noise or (particularly in electronics) as shot noise is a type of
 * electronic noise that occurs when the finite number of particles that carry
 * energy, such as electrons in an electronic circuit or photons in an optical
 * device, is small enough to give rise to detectable statistical fluctuations
 * in a measurement. It is important in electronics, telecommunications, and
 * fundamental physics.
 * 
 */
public class Poisson_Noise implements PlugInFilter {
   ImagePlus imp;
   Random random = new Random();

   public int setup(String arg, ImagePlus imp) {
      if (imp == null) {
         IJ.noImage();
         return DONE;
      }
      this.imp = imp;
      return IJ.setupDialog(imp, DOES_ALL | SUPPORTS_MASKING);
   }

   public void run(ImageProcessor ip) {
      FloatProcessor fp = null;
      for (int i = 0; i < ip.getNChannels(); i++) { // grayscale: once. RBG:
         // once per color, i.e., 3 times
         fp = ip.toFloat(i, fp); // convert image or color channel to float

         addNoiseInt(fp);

         ip.setPixels(i, fp); // convert back from float
      }
   }

   public void addNoiseInt(ImageProcessor ip) {
      int width = ip.getWidth(); // width of the image
      int height = ip.getHeight(); // height of the image
      // double max = ip.getMax();
      float[] pixels = (float[]) ip.getPixels();
      int progress = Math.max(height / 25, 1);
      Rectangle r = ip.getRoi();

      for (int y = r.y; y < (r.y + r.height); y++) {
         if (y % progress == 0)
            IJ.showProgress(y, height);
         for (int x = r.x; x < (r.x + r.width); x++) {
            // Creates additive poisson noise
            float pixVal = pixels[y * width + x];
            // double newVal = pixVal + poissonValue(pixVal);
            double newVal = poissonValue(pixVal);
            // newVal = Math.max(newVal, 0);
            // if (newVal <= max)
            pixels[x + y * width] = (float) newVal;
         }
      }
      IJ.showProgress(1.0);
      ip.resetMinAndMax();
   }

   /**
    * Algorithm poisson random number (Knuth). While simple, the complexity is
    * linear in λ (the mean).
    * 
    * @return a random Poisson-distributed number.
    */
   private int poissonValue(float pixVal) {

      double L = Math.exp(-(pixVal));
      int k = 0;
      double p = 1;
      do {
         k++;
         // Generate uniform random number u in [0,1] and let p ← p × u.
         p *= random.nextDouble();
      } while (p >= L);
      return (k - 1);
   }

}